﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("a = ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("b = ");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("a + b = " + (a + b));
            Console.WriteLine("a - b = " + (a - b));
            Console.WriteLine("a * b = " + (a * b));
            Console.WriteLine("a / b = " + (a / b));
            Console.WriteLine("a % b = " + (a % b));
            Console.WriteLine("a++ = " + a++);
            Console.WriteLine("++b = " + ++b);
            Console.WriteLine("a-- = " + a--);
            Console.WriteLine("--b = " + --b);
            Console.WriteLine("a > b = " + (a > b));
            Console.WriteLine("a == b = " + (a == b));
            Console.WriteLine("con" + "catenation");

            Console.ReadKey();
        }

     }
}
