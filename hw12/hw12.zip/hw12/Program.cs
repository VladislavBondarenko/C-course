﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw12
{
    class Program
    {
        static void Main(string[] args)
        {
            Journal journal = new Journal();

            byte point;
            bool cont = true;
            while (cont)
            {
                Console.Clear();
                Console.WriteLine("Выберите работника, для подсчета его зарплаты\n");
                Console.WriteLine("1. Добавить ученика");
                Console.WriteLine("2. Поставить оценку ученику");
                Console.WriteLine("3. Посмотреть средний балл ученика");
                Console.WriteLine("4. Посмотреть все оценки учеников");
                Console.WriteLine("5. Посмотреть список учеников");
                Console.WriteLine("0. Выйти");
                Console.WriteLine();
                point = (byte)Tools.InputNumber("Пункт: ", 0, 5);
                Console.WriteLine();
                switch (point)
                {
                    case 1: journal.AddPupil();
                        Console.ReadKey();
                        break;
                    case 2:
                        journal.AddMark();
                        Console.ReadKey();
                        break;
                    case 3:
                        journal.ShowAvgMarkSomePupil();
                        Console.ReadKey();
                        break;
                    case 4:
                        journal.ShowAllMarks();
                        Console.ReadKey();
                        break;
                    case 5:
                        journal.ShowAllPupilsWithAge();
                        Console.ReadKey();
                        break;
                    case 0: cont = false; break;
                }
            }
        }
    }
}
