﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw12
{
    class Journal
    {
        protected List<Pupil> Pupils;
        protected byte MinMark;
        protected byte MaxMark;

        public Journal()
        {
            this.Pupils = new List<Pupil>();
            this.MinMark = 1;
            this.MaxMark = 12;
        }

        public void AddPupil()
        {
            Console.Write("Введите имя ученика: ");
            string name = Console.ReadLine();
            byte age = Tools.InputNumber("Введите возраст ученика: ", 1, 100);
            this.Pupils.Add(new Pupil(name, age));
            Console.WriteLine("Выполнено");
        }

        public void AddMark()
        {
            if (this.ShowAllPupils())
            {
                Pupil curPupil = this.Pupils[Tools.InputNumber("Выберите ученика: ", 1, this.Pupils.Count) - 1];
                Console.WriteLine("Введите название предмета: ");
                string subject = Console.ReadLine();
                byte mark = Tools.InputNumber("Введите оценку: ", this.MinMark, this.MaxMark);
                curPupil.AddMark(subject, mark);
                Console.WriteLine("Выполнено");
            }
        }

        public bool ShowAllPupils()
        {
            int count = 0;
            foreach (Pupil pupil in this.Pupils)
            {
                count++;
                Console.WriteLine("{0}. {1}", count, pupil.Name);
            }
            if (count > 0)
            {
                return true;
            }
            Console.WriteLine("Список учеников пуст");
            return false;
        }

        public bool ShowAllPupilsWithAge()
        {
            int count = 0;
            foreach (Pupil pupil in this.Pupils)
            {
                count++;
                Console.WriteLine("{0}. {1} ({2} лет)", count, pupil.Name, pupil.Age);
            }
            if (count > 0)
            {
                return true;
            }
            Console.WriteLine("Список учеников пуст");
            return false;
        }

        public void ShowAvgMarkSomePupil()
        {
            if (this.ShowAllPupils())
            {
                Pupil curPupil = this.Pupils[Tools.InputNumber("Выберите ученика: ", 1, this.Pupils.Count) - 1];
                Console.WriteLine("Средний балл = {0}", curPupil.GetAvgMark());
            }
        }

        public void ShowAllMarks()
        {
            if (this.Pupils.Count > 0)
            {
                byte mainAge = Tools.InputNumber("Возраст ученика больше (лет): ", 0, 100);
                foreach (Pupil pupil in this.Pupils)
                {
                    if (pupil.Age > mainAge)
                    {
                        Console.WriteLine("{0}:", pupil.Name);
                        pupil.ShowAllMarks();
                        Console.WriteLine(new string('-', 30));
                    }
                }
            } 
            else
            {
                Console.WriteLine("Список учеников пуст");
            }
        }
    }
}
