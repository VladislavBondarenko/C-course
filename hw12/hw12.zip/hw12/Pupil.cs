﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw12
{
    class Pupil
    {
        public string Name { set; get; }
        public int Age { set; get; }
        public KeyValuePair<string, byte> MarkList { set; get; }
    }
}
