﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw12
{
    class Teacher
    {
        protected List<Pupil> Pupils;

        public Teacher()
        {
            this.Pupils = new List<Pupil>();
        }

        public void AddPupil()
        {
            Console.WriteLine("Введите имя ученика: ");
            string name = Console.ReadLine();
        }

        public void AddMark()
        {

        }

        public void ShowAverageMark()
        {

        }

        public void ShowAllMarks()
        {

        }
    }
}
