﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw7
{
    class Employee
    {
        public int Experience { set; get; }
        public double Rate { set; get; }
        public string Name { set; get; }
        public int RatioBonusHours { set; get; }

        public Employee(string nameArg, int experienceArg, double rateArg, int ratioBonusHours)
        {
            this.Name = nameArg;
            this.Experience = experienceArg;
            this.Rate = rateArg;
            this.RatioBonusHours = ratioBonusHours;
        }
    }
}
