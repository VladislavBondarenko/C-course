﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw7
{
    class Worker : Employee
    {
        public double RatioRateOvertime { set; get; }

        public Worker(string nameArg, int experienceArg, double rateArg, double ratioRateOvertime, int ratioBonusHours)
            :base(nameArg, experienceArg, rateArg, ratioBonusHours)
        {
            this.RatioRateOvertime = ratioRateOvertime;
        }
    }
}
