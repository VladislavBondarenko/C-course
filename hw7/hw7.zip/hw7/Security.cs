﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw7
{
    class Security: Employee
    {
        public double RatioRateNight { set; get; }
        public int RatioBonusNightHours { set; get; }

        public Security(string nameArg, int experienceArg, double rateArg, double ratioRateNight, int ratioBonusHours, int ratioBonusNightHours)
            :base(nameArg, experienceArg, rateArg, ratioBonusHours)
        {
            this.RatioRateNight = ratioRateNight;
            this.RatioBonusNightHours = ratioBonusNightHours;
        }
    }
}
