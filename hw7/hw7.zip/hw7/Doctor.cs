﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw7
{
    class Doctor : Employee
    {
        public double BonusOneCured { set; get; }
        public byte NumberCured { set; get; }

        public Doctor(string nameArg, int experienceArg, double rateArg, double bonusOneCuredArg, int ratioBonusHours)
            :base(nameArg, experienceArg, rateArg, ratioBonusHours)
        {
            this.BonusOneCured = bonusOneCuredArg;
        }
    }
}
