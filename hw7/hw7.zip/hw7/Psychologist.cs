﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw7
{
    class Psychologist : Employee
    {
        public decimal RatePatient { protected set; get; }
        public decimal RatioRateAdditionalPatient { protected set; get; }
        public int NumberPatients { protected set; get; }
        public int AdditionalPatiens { protected set; get; }

        public Psychologist(string name, int experience, decimal rate, decimal ratePatient, decimal ratioRateAdditionalPatient, decimal ratioBonusHours)
            :base(name, experience, rate, ratioBonusHours)
        {
            this.RatePatient = ratePatient;
            this.RatioRateAdditionalPatient = ratioRateAdditionalPatient;
        }

        public override void AskData()
        {
            this.NumberPatients = Tools.InputNumber("Сколько пациентов было принято за месяц?: ", 0, 500);
            this.BonusHours = (byte)Tools.InputNumber("Сколько насчитано премиальных часов?: ", 0, 200);
        }

        public override void AskBonus()
        {
            this.AdditionalPatiens = Tools.InputNumber("Сколько из всех пациентов были дополнительными?: ", 0, this.NumberPatients);
        }

        public override decimal CountBasicSalary()
        {
            return (this.NumberPatients - this.AdditionalPatiens) * this.RatePatient;
        }

        public override decimal CountBonusSalary()
        {
            return this.AdditionalPatiens * this.RatePatient * this.RatioRateAdditionalPatient;
        }
    }

    class InternPsychologist : Psychologist
    {
        public InternPsychologist(Psychologist psychologist, string name, decimal ratioBonusHours)
            : base(name, psychologist.Experience, psychologist.Rate, psychologist.RatePatient, psychologist.RatioRateAdditionalPatient, ratioBonusHours) { }
    }
}
