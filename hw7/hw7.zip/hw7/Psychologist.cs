﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw7
{
    class Psychologist : Employee
    {
        public double RatePatient { set; get; }
        public double RatioRateAdditionalPatient { set; get; }

        public Psychologist(string nameArg, int experienceArg, double rateArg, double ratePatient, double ratioRateAdditionalPatient, int ratioBonusHours)
            :base(nameArg, experienceArg, rateArg, ratioBonusHours)
        {
            this.RatePatient = ratePatient;
            this.RatioRateAdditionalPatient = ratioRateAdditionalPatient;
        }
    }
}
