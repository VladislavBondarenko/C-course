﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw7
{
    class Accountant
    {
        public static void CountSalary(Employee employee)
        {
            double salary = 0;
            if (!(employee is Psychologist)) {
                byte days = InputNumber("Сколько дней в этом месяце работал?: ", 0, 31);
                byte hours = InputNumber("Сколько часов в день?:", 0, 24);
                byte bonusHours = InputNumber("Сколько насчитано премиальных часов?: ", 0, 200);
                if (employee is Doctor)
                {
                    byte cured = InputNumber("Сколько больных вылечил?: ", 0, 200);
                    salary = employee.Rate * (days * hours + bonusHours * ((Doctor)employee).RatioBonusHours )
                        + cured * ((Doctor)employee).BonusOneCured;
                }
                if (employee is Worker)
                {
                    byte overtime = InputNumber("Сколько было сверхурочных часов?: ", 0, 200);
                    salary = employee.Rate * (hours * days
                        + ((Worker)employee).RatioRateOvertime * overtime
                        + ((Worker)employee).RatioBonusHours * bonusHours);
                }
                if (employee is Security)
                {
                    byte nights = InputNumber("Сколько из них было ночных за месяц?: ", 0, days * hours);
                    salary = employee.Rate * (hours * days - nights 
                        + ((Security)employee).RatioBonusHours * bonusHours
                        + (((Security)employee).RatioRateNight - 1) * nights);
                }
            }
            if (employee is Psychologist)
            {
                byte numberPatients = InputNumber("Сколько пациентов было принято за месяц?: ", 0, 200);
                byte additionalPatiens = InputNumber("Сколько из них дополнительных?: ", 0, numberPatients);
                byte bonusHours = InputNumber("Сколько насчитано премиальных часов?: ", 0, 200);
                salary = ((Psychologist)employee).RatePatient * ((numberPatients - additionalPatiens)
                    + additionalPatiens * ((Psychologist)employee).RatioRateAdditionalPatient)
                    + bonusHours * ((Psychologist)employee).RatioBonusHours * employee.Rate;
            }
            Console.WriteLine("\nЗаработок этого работника за месяц = " + salary);
            Console.ReadKey();
        }

        public static byte InputNumber(string field, int min, int max)
        {
            byte result;
            while (true)
            {
                Console.Write(field);
                string buf = Console.ReadLine();
                if (Byte.TryParse(buf, out result) && (result <= max) && (result >= min))
                {
                    return result;
                }
                else
                {
                    Console.WriteLine("Некорректное значение. Попробуйте еще раз");
                }
            }
        }
    }
}
