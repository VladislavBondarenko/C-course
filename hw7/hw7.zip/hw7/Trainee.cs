﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw7
{
    sealed class Trainee
    {
        public Employee Master { set; get; }
        public string Name { private set; get; }
        public decimal RatioBonusHours { private set; get; }

        public Trainee(Employee employee, string name, decimal ratioBonusHours)
        {
            this.Master = employee;
            this.Name = name;
            this.RatioBonusHours = ratioBonusHours;
        }

        public decimal CountBonusHoursSalary()
        {
            return this.Master.BonusHours * this.Master.Rate * this.RatioBonusHours;
        }
    }
}
