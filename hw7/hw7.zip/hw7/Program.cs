﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw7
{
    class Program
    {
        static void Main(string[] args)
        {
            Doctor doctor = new Doctor("doctor", 3, 15, 20, 0);
            Psychologist psychologist = new Psychologist("psychologist", 4, 12, 16, 1.2, 2);
            Worker worker = new Worker("worker", 1, 10, 1.2, 4);
            Security security = new Security("security", 2, 8, 1.5, 2, 3);

            byte point;
            bool cont = true;
            while (cont)
            {
                Console.Clear();
                Console.WriteLine("Выберите работника, для подсчета его зарплаты\n");
                Console.WriteLine("1. Врач");
                Console.WriteLine("2. Психолог");
                Console.WriteLine("3. Обычный работник");
                Console.WriteLine("4. Охранник");
                Console.WriteLine("0. Выйти");
                Console.WriteLine();
                point = Accountant.InputNumber("Пункт: ", 0, 4);
                Console.WriteLine();
                switch (point)
                {
                    case 1: Accountant.CountSalary(doctor); break;
                    case 2:Accountant.CountSalary(psychologist); break;
                    case 3:Accountant.CountSalary(worker); break;
                    case 4: Accountant.CountSalary(security); break;
                    case 0: cont = false; break;
                }
            }
        }

        
    }
}
