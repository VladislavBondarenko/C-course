﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw14
{
    class Program
    {
        static void Main(string[] args)
        {
            SaleRepository repository = new SaleRepository();

            byte point;
            bool cont = true;
            while (cont)
            {
                Console.Clear();
                Console.WriteLine("1. Query");
                Console.WriteLine("2. Pagination");
                Console.WriteLine("3. Search by words");
                Console.WriteLine("0. Exit");
                Console.WriteLine();
                point = (byte)Tools.InputNumber("Point: ", 0, 3);
                Console.WriteLine();
                switch (point)
                {
                    case 1:
                        Console.Clear();
                        repository.Query();
                        Console.ReadKey();
                        break;
                    case 2:
                        repository.Pagination();
                        break;
                    case 3:
                        Console.Clear();
                        repository.Search();
                        Console.ReadKey();
                        break;
                    case 0: cont = false; break;
                }
            }
        }
    }
}
