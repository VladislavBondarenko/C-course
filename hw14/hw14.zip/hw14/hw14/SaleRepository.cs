﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw14
{
    class SaleRepository
    {
        public List<Sale> Sales { get; set; }

        public SaleRepository()
        {
            Sales = new List<Sale>()
            {
                new Sale() { Id = 1, Ware = "new phone", Number = 3, Price = 100, Discount = 20, Sum = 280 },
                new Sale() { Id = 2, Ware = "computer", Number = 3, Price = 1100, Discount = 300, Sum = 3000 },
                new Sale() { Id = 3, Ware = "guitar", Number = 1, Price = 300, Discount = 50, Sum = 250 },
                new Sale() { Id = 4, Ware = "new violin", Number = 4, Price = 600, Discount = 0, Sum = 2400 },
                new Sale() { Id = 5, Ware = "new keyboard", Number = 5, Price = 20, Discount = 10, Sum = 90 },
                new Sale() { Id = 6, Ware = "new mouse", Number = 8, Price = 10, Discount = 10, Sum = 70 },
                new Sale() { Id = 7, Ware = "camera", Number = 4, Price = 10, Discount = 10, Sum = 30 },
            };
        }

        public void Pagination()
        {
            int pageSize = 2;
            int page = 1;
            while (true)
            {
                PageInfo pageInfo = new PageInfo { PageNumber = page, PageSize = pageSize, TotalItems = this.Sales.Count };
                ShowPage(pageInfo);
                page = Tools.InputNumber("Choose page: ", 0, pageInfo.TotalPages);
                if (page == 0)
                {
                    return;
                }
            }
        }

        protected void ShowPage(PageInfo pageInfo)
        {
            IEnumerable<Sale> results = this.Sales.Skip((pageInfo.PageNumber - 1) * pageInfo.PageSize).Take(pageInfo.PageSize);
            Console.Clear();
            foreach (var sale in results)
            {
                Console.WriteLine("Id: {0}\nWare: {1}\nPrice: {2}\nNumber: {3}\nDiscount: {4}\nSum: {5}\n" +
                    new string('-', 20) + "\n",
                    sale.Id, sale.Ware, sale.Price, sale.Number, sale.Discount, sale.Sum);
            }
            Console.WriteLine("Page: {0}/{1} (0 - exit from pagination)", pageInfo.PageNumber, pageInfo.TotalPages);
        }

        public void Query()
        {
            var query = from sale in this.Sales
                        where sale.Discount > 0 &&
                        sale.Price <= 1000 &&
                        sale.Number > 2 &&
                        sale.Ware.Contains("new")
                        select new
                        {
                            sale.Id,
                            sale.Sum
                        };
            Console.WriteLine("Sales with Discount > 0, Price <= 1000, Number > 2, new:\n");
            foreach (var item in query)
            {
                Console.WriteLine("Id: {0}, Sum: {1}", item.Id, item.Sum);
            }
        }

        public void Search()
        {
            Console.Write("Your query: ");
            string query = Console.ReadLine();
            string[] words = query.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var result = (from sale in this.Sales
                         from word in words
                         where sale.Ware.Contains(word)
                         select new
                         {
                             sale.Id,
                             sale.Ware
                         }).Distinct();
            foreach (var item in result)
            {
                Console.WriteLine("Id: {0}, Ware: {1}", item.Id, item.Ware);
            }
            if (result.Count() == 0)
            {
                Console.WriteLine("No matches");
            }
        }
    }
}
