﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw5_6
{
    class GirlScout:Scout
    {
        private String[] sportAvailable;

        public GirlScout(string name):base(name)
        {
            this.sportAvailable = new String[] { "Шейпинг", "Танцы", "Теннис" };
        }

        public string GetNameSportAvailable(int index)
        {
            return this.sportAvailable[index];
        }

        public byte GetLengthSportAvailable()
        {
            return (byte)this.sportAvailable.Length;
        }

        public void ShowSportAvailable()
        {
            for (int i = 0; i < this.sportAvailable.Length; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, this.sportAvailable[i]);
            }
        }
    }
}
