﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw5_6
{
    class BoyScout:Scout
    {
        private String[] sportAvailable;

        public BoyScout(string name):base(name)
        {
            this.sportAvailable = new String[] { "Футбол", "Бокс", "Борьба", "Армрестлинг", "Гиревой спорт"};
        }

        public byte GetLengthSportAvailable()
        {
            return (byte)this.sportAvailable.Length;
        }

        public string GetNameSportAvailable(int index)
        {
            return this.sportAvailable[index];
        }

        public void ShowSportAvailable()
        {
            for (int i = 0; i < this.sportAvailable.Length; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, this.sportAvailable[i]);
            }
        }
    }
}
