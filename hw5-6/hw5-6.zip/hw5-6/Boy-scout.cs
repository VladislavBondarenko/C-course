﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw5_6
{
    class BoyScout:Scout
    {
        public BoyScout(string name):base(name)
        {
        }
    }
}
