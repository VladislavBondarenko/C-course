﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw5_6
{
    class Scout
    {
        public string Name { set; get; }
        private List<Sport> sports = new List<Sport>();

        public Scout(string nameArg)
        {
            this.Name = nameArg;
        }

        public int GetSportsLength()
        {
            return this.sports.Count;
        }

        public void ShowAllSports()
        {
            for (int i = 0; i < this.sports.Count; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, this.sports[i].Name);
            }
        }

        public void AddSport(string sport, byte mark)
        {
            this.sports.Add(new Sport(sport, mark));
        }

        public void RemoveSport(byte number)
        {

            this.sports.Remove(this.sports[number]);
        }

        public double GetAvgAllSports()
        {
            if (this.sports.Count != 0)
            {
                return (double)(GetSumMarks()) / this.sports.Count;
            }
            return 0;
            
        }

        public int GetSumMarks()
        {
            int result = 0;
            foreach(Sport sport in this.sports)
            {
                result += sport.Mark;
            }
            return result;
        }
    }
    
}
