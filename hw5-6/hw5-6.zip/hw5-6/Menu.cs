﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw5_6
{
    class Menu
    {
        List<Scout> scouts = new List<Scout>();

        public void AddBoyScout()
        {
            Console.Write("Имя: ");
            string name = Console.ReadLine();
            this.scouts.Add(new BoyScout(name));
            Console.WriteLine("Выполнено");
        }

        public void AddGirlScout()
        {
            Console.Write("Имя: ");
            string name = Console.ReadLine();
            this.scouts.Add(new GirlScout(name));
            Console.WriteLine("Выполнено");
        }

        public void ShowAllScouts()
        {
            if (this.scouts.Count == 0)
            {
                Console.WriteLine("Мальчиков скаутов в лагере нет");
            }
            else
            {
                for (int i = 0; i < this.scouts.Count; i++)
                {
                    Console.Write("{0}. {1}", i + 1, this.scouts[i].Name);
                    if (this.scouts[i] is BoyScout)
                    {
                        Console.WriteLine(" М");
                    }
                    else
                    {
                        Console.WriteLine(" Ж");
                    }
                }
            }
        }

        public void ShowAllBoyScouts()
        {
            byte i = 1;
            foreach (Scout scout in this.scouts)
            {
                if (scout is BoyScout)
                {
                    Console.WriteLine("{0}. {1} М", i, scout.Name);
                    i++;
                }
            }
            if (i == 1)
            {
                Console.WriteLine("Мальчиков скаутов в лагере нет");
            }
        }

        public void ShowAllGirlScouts()
        {
            byte i = 1;
            foreach (Scout scout in this.scouts)
            {
                if (scout is GirlScout)
                {
                    Console.WriteLine("{0}. {1} Ж", i, scout.Name);
                    i++;
                }
            }
            if (i == 1)
            {
                Console.WriteLine("Девочек скаутов в лагере нет");
            }
        }

        public void AddSport()
        {
            Console.WriteLine("Выберите скаута: ");
            ShowAllScouts();
            byte number = InputNumber("Номер: ", 1, this.scouts.Count);
            Console.Write("Спорт: ");
            string sport = Console.ReadLine();
            Console.Write("Оценка: ");
            byte mark = InputNumber("Оценка (0-100): ", 0, 100);
            this.scouts[number - 1].AddSport(sport, mark);
            Console.WriteLine("Выполнено");
        }

        public void DeleteSport()
        {
            Console.WriteLine("Выберите скаута: ");
            ShowAllScouts();
            byte numberScout = InputNumber("Номер: ", 1, this.scouts.Count);
            if (this.scouts[numberScout - 1].GetSportsLength() != 0)
            {
                Console.WriteLine("Выберите спорт: ");
                this.scouts[numberScout - 1].ShowAllSports();
                byte numberSport = InputNumber("Номер: ", 1, this.scouts[numberScout - 1].GetSportsLength());
                this.scouts[numberSport - 1].RemoveSport(numberSport);
                Console.WriteLine("Выполнено");
            }
            else
            {
                Console.WriteLine("Удалять нечего");
            }
            
        }

        public void CalcAvgMarkScout()
        {
            Console.WriteLine("Выберите скаута: ");
            ShowAllScouts();
            byte numberScout = InputNumber("Номер: ", 1, this.scouts.Count);
            Console.WriteLine("Средний балл у скаута = " + this.scouts[numberScout - 1].GetAvgAllSports());
        }

        public double GetAvgMarkAllScouts()
        {
            double result = 0;
            foreach(Scout scout in this.scouts)
            {
                result += scout.GetAvgAllSports();
            }
            return result;
        }

        public void ShowAllCalc()
        {
            Scout bestBoyScout = new BoyScout("отсутствует");
            Scout smashBoyScout = bestBoyScout;
            Scout activeBoyScout = bestBoyScout;
            Scout lazyBoyScout = bestBoyScout;
            Scout bestGirlScout = new GirlScout("отсутствует");
            Scout smashGirlScout = bestGirlScout;
            Scout activeGirlScout = bestGirlScout;
            Scout lazyGirlScout = bestGirlScout;

            foreach(Scout scout in this.scouts)
            {
                if (scout is BoyScout)
                {
                    lazyBoyScout = scout;
                    break;
                }
            }

            foreach (Scout scout in this.scouts)
            {
                if (scout is GirlScout)
                {
                    lazyGirlScout = scout;
                    break;
                }
            }

            foreach (Scout scout in this.scouts)
            {
                if(scout is BoyScout)
                {
                    if (scout.GetAvgAllSports() >= bestBoyScout.GetAvgAllSports())
                    {
                        bestBoyScout = scout;
                    }
                    if (scout.GetSumMarks() >= smashBoyScout.GetSumMarks())
                    {
                        smashBoyScout = scout;
                    }
                    if (scout.GetSportsLength() >= activeBoyScout.GetSportsLength())
                    {
                        activeBoyScout = scout;
                    }
                    if (scout.GetSportsLength() <= lazyBoyScout.GetSportsLength())
                    {
                        lazyBoyScout = scout;
                    }
                } else
                {
                    if (scout.GetAvgAllSports() >= bestGirlScout.GetAvgAllSports())
                    {
                        bestGirlScout = scout;
                    }
                    if (scout.GetSumMarks() >= smashGirlScout.GetSumMarks())
                    {
                        smashGirlScout = scout;
                    }
                    if (scout.GetSportsLength() >= activeGirlScout.GetSportsLength())
                    {
                        activeGirlScout = scout;
                    }
                    if (scout.GetSportsLength() <= lazyGirlScout.GetSportsLength())
                    {
                        lazyGirlScout = scout;
                    }
                }
            }

            Console.WriteLine("Средний балл лагеря = " + this.GetAvgMarkAllScouts());
            Console.WriteLine("Лучший скаут мальчик - {0}, его средний балл = {1}", 
                bestBoyScout.Name, 
                bestBoyScout.GetAvgAllSports());
            Console.WriteLine("Лучшая скаут девочка - {0}, ее средний балл = {1}",
                bestGirlScout.Name,
                bestGirlScout.GetAvgAllSports());
            Console.WriteLine("Самый успешный скаут мальчик - {0}, его сумма баллов = {1}",
                smashBoyScout.Name,
                smashBoyScout.GetSumMarks());
            Console.WriteLine("Самая успешная скаут девочка - {0}, ее сумма баллов = {1}",
                smashGirlScout.Name,
                smashGirlScout.GetSumMarks());
            Console.WriteLine("Самый активный скаут мальчик - {0}, количество его наград = {1}",
                activeBoyScout.Name,
                activeBoyScout.GetSportsLength());
            Console.WriteLine("Самая активная скаут девочка - {0}, количество ее наград = {1}",
                activeGirlScout.Name,
                activeGirlScout.GetSportsLength());
            Console.WriteLine("Самый ленивый скаут мальчик - {0}, количество его наград = {1}",
                lazyBoyScout.Name,
                lazyBoyScout.GetSportsLength());
            Console.WriteLine("Самая ленивая скаут девочка - {0}, количество ее наград = {1}",
                lazyGirlScout.Name,
                lazyGirlScout.GetSportsLength());
        }

        public byte InputNumber(string field, int min, int max)
        {
            byte result;
            while (true)
            {
                Console.Write(field);
                string buf = Console.ReadLine();
                if (Byte.TryParse(buf, out result) && (result <= max) && (result >= min) )
                {
                    return result;
                }
                else
                {
                    Console.WriteLine("Некорректное значение. Попробуйте еще раз");
                }
            }
        }
    }
}
