﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw9
{
    static class Tools
    {
        public static Russian russian = new Russian("russian");
        public static Ukrainian ukrainian = new Ukrainian("ukrainian");
        public static American american = new American("american");

        static private int CheckLanguage(this string text)
        {
            text = text.ToLower();
            int rusCount = 0;
            int ukrCount = 0;
            int engCount = 0;
            foreach (char c in text)
            {
                if (c >= 'a' && c <= 'z')
                {
                    engCount++;
                }
                else
                {
                    if (c >= 'а' && c <= 'я')
                    {
                        rusCount++;
                        if (c != 'ы' && c != 'ъ' && c != 'э')
                        {
                            ukrCount++;
                        }
                    }
                    else
                    {
                        if (c == '?' || c == 'є' || c == 'ї')
                        {
                            ukrCount++;
                        }
                    }
                }
            }
            if (rusCount > engCount)
            {
                if (rusCount >= ukrCount)
                {
                    return (int)lang.rus;
                } else
                {
                    return (int)lang.ukr;
                }
            } else
            {
                if (engCount > ukrCount)
                {
                    return (int)lang.eng;
                } else
                {
                    return (int)lang.ukr;
                }
            }
        }

        public static Bot GetBot(this string phrase)
        {
            int language = phrase.CheckLanguage();

            if (language == (int)lang.rus)
            {
                return russian;
            }
            if (language == (int)lang.ukr)
            {
                return ukrainian;
            }
            if (language == (int)lang.eng)
            {
                return american;
            }
            else
            {
                return null;
            }
        }

        enum lang
        {
            rus,
            ukr,
            eng
        }
    }
}
