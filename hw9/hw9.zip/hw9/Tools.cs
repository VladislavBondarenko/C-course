﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw9
{
    static class Tools
    {
        public static Russian russian = new Russian("russian");
        public static Ukrainian ukrainian = new Ukrainian("ukrainian");
        public static American american = new American("american");

        static private lang CheckLanguage(this string text)
        {
            text = text.ToLower();

            int engCount = text.Count(c => (c >= 'a' && c <= 'z'));
            int rusCount = text.Count(c => (c >= 'а' && c <= 'я'));
            int ukrCount = text.Count(c => ((c == '?' || c == 'є' || c == 'ї') ||
                ((c >= 'а' && c <= 'я') && (c != 'ы' && c != 'ъ' && c != 'э'))));

            return (rusCount > engCount ?
                (rusCount >= ukrCount ? lang.rus : lang.ukr) :
                (engCount > ukrCount ? lang.eng : lang.ukr));
        }

        public static Bot GetBot(this string phrase)
        {
            lang language = phrase.CheckLanguage();
            switch (language)
            {
                case lang.rus: return russian;
                case lang.ukr: return ukrainian;
                case lang.eng: return american;
                default: return null;
            }
        }

        enum lang
        {
            rus,
            ukr,
            eng
        }
    }
}
